

document.addEventListener('DOMContentLoaded', () => {
    const valorAnteriorElemento = document.getElementById('valor-anterior');
    const valorActualElemento = document.getElementById('valor-actual');
    const botonesNumeros = document.querySelectorAll('.btn-numero');
    const botonesOperadores = document.querySelectorAll('.btn-operador');
    const botonLimpiar = document.getElementById('limpiar');
    const botonIgual = document.getElementById('igual');
    const botonBorrar = document.getElementById('borrar');
    let valorActual = '0';
    let valorAnterior = '';
    let operacionPendiente = undefined;
    function actualizarPantalla() {
        valorActualElemento.textContent = valorActual;
        valorAnteriorElemento.textContent = valorAnterior;
    }

    function agregarNumero(numero) {
        if (valorActual === '0' && numero !== '.') {
            valorActual = numero;
        } else {
            if (numero === '.' && valorActual.includes('.')) return;
            valorActual += numero;
        }
        actualizarPantalla();
    }
    function seleccionarOperacion(operacion) {
        if (valorActual === 'Error') return;
        if (valorActual === '') return;
        if (valorAnterior !== '') {
            calcular();
        }

        switch (operacion) {
            case 'sumar':
                operacionPendiente = '+';
                break;
            case 'restar':
                operacionPendiente = '-';
                break;
            case 'multiplicar':
                operacionPendiente = '*';
                break;
            case 'dividir':
                operacionPendiente = '/';
                break;
            default:
                return;
        }

        valorAnterior = valorActual + ' ' + operacionPendiente;
        valorActual = '';
        actualizarPantalla();
    }
    function calcular() {
        if (valorAnterior === '' || valorActual === '' || valorActual === 'Error') return;
        const anteriorNum = parseFloat(valorAnterior.split(' ')[0]);
        const actualNum = parseFloat(valorActual);
        if (isNaN(anteriorNum) || isNaN(actualNum)) return;
        let calculo;
        switch (operacionPendiente) {
            case '+':
                calculo = anteriorNum + actualNum;
                break;
            case '-':
                calculo = anteriorNum - actualNum;
                break;
            case '*':
                calculo = anteriorNum * actualNum;
                break;
            case '/':
                if (actualNum === 0) {
                    valorActual = 'Error';
                    valorAnterior = '';
                    operacionPendiente = undefined;
                    actualizarPantalla();
                    return;
                }

                calculo = anteriorNum / actualNum;
                break;
            default:
                return;
        }
        valorActual = calculo.toString();
        operacionPendiente = undefined;
        valorAnterior = '';
        actualizarPantalla();
    }
    function limpiar() {
        valorActual = '0';
        valorAnterior = '';
        operacionPendiente = undefined;
        actualizarPantalla();
    }
    function borrar() {
        if (valorActual === 'Error' || valorActual.length === 1) {
            valorActual = '0';
        } else {
            valorActual = valorActual.slice(0, -1);
        }
        actualizarPantalla();
    }
    botonesNumeros.forEach(boton => {
        boton.addEventListener('click', () => {
            agregarNumero(boton.getAttribute('value'));
        });
    });

    botonesOperadores.forEach(boton => {
        if (boton.id === 'limpiar' || boton.id === 'borrar') return;
        boton.addEventListener('click', () => {
            seleccionarOperacion(boton.getAttribute('value'));
        });
    });
    botonLimpiar.addEventListener('click', limpiar);
    botonBorrar.addEventListener('click', borrar);
    botonIgual.addEventListener('click', calcular);
    document.addEventListener('keydown', (event) => {
        if (event.key >= '0' && event.key <= '9') {
            agregarNumero(event.key);
        } else if (event.key === '.') {
            agregarNumero('.');
        } else if (event.key === '+') {
            seleccionarOperacion('sumar');
        } else if (event.key === '-') {
            seleccionarOperacion('restar');
        } else if (event.key === '*') {
            seleccionarOperacion('multiplicar');
        } else if (event.key === '/') {
            event.preventDefault();
            seleccionarOperacion('dividir');
        } else if (event.key === 'Enter' || event.key === '=') {
            event.preventDefault();
            calcular();
        } else if (event.key === 'Escape') {
            limpiar();
        } else if (event.key === 'Backspace') {
            borrar();
        }
    });
    actualizarPantalla();
});